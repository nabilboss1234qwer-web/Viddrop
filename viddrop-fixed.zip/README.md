# VidDrop

Downloads public videos (YouTube, TikTok, Instagram, Facebook, X and 1000+ other sites) up to 1080p Full HD
and saves them into your gallery (`Movies/VidDrop`, audio in `Music/VidDrop`).

Engine: [youtubedl-android](https://github.com/JunkFood02/youtubedl-android) (yt-dlp + ffmpeg running on the device).
yt-dlp auto-updates once a day (Settings → "Update Download Engine" to force it).

## Build
1. Open in Android Studio, let Gradle sync (needs internet for dependencies).
2. Run on a device/emulator (API 24+). The first launch unpacks the engine (a few seconds).
3. Release builds are signed with the debug key unless `STORE_PASSWORD`, `KEY_PASSWORD`, `KEYSTORE_PATH` env vars are set.

Only download content you own or have permission to save. Respect each platform's terms.
