package com.viddrop

import android.app.Application
import com.viddrop.data.engine.YtDlpEngine
import com.viddrop.data.local.VidDropDatabase
import com.viddrop.data.repository.DownloadRepository
import com.viddrop.data.settings.SettingsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AppContainer(app: Application) {
    val settings = SettingsStore(app)
    val database = VidDropDatabase.getDatabase(app)
    val repository = DownloadRepository(app, database.downloadDao(), settings)
}

class App : Application() {
    lateinit var container: AppContainer
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        val processStart = System.currentTimeMillis()
        container = AppContainer(this)
        appScope.launch {
            container.repository.recoverInterrupted(processStart)
            runCatching { YtDlpEngine.ensureInit(this@App) }
            // Keep yt-dlp fresh (sites break it often): at most once a day, silently.
            val now = System.currentTimeMillis()
            if (now - container.settings.lastEngineUpdate > 24L * 60 * 60 * 1000) {
                runCatching { YtDlpEngine.update(this@App) }.onSuccess {
                    container.settings.lastEngineUpdate = now
                }
            }
        }
    }
}
