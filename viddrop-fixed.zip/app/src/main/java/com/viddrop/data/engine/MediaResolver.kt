package com.viddrop.data.engine

import android.content.Context
import com.viddrop.data.model.VideoMetadata
import com.viddrop.data.settings.Qualities
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.URI
import java.util.Locale

object MediaResolver {

    suspend fun resolve(context: Context, input: String): VideoMetadata = withContext(Dispatchers.IO) {
        val url = input.trim()
        val uri = runCatching { URI(url) }.getOrNull()
        val scheme = uri?.scheme?.lowercase(Locale.ROOT)
        val host = uri?.host
        if ((scheme != "http" && scheme != "https") || host.isNullOrBlank()) {
            throw IllegalArgumentException("Invalid URL. It must start with http:// or https://")
        }

        YtDlpEngine.ensureInit(context)

        val info = try {
            YoutubeDL.getInstance().getInfo(
                YoutubeDLRequest(url).apply {
                    addOption("--no-playlist")
                    addOption("--socket-timeout", "20")
                }
            )
        } catch (e: Exception) {
            throw IOException(YtDlpEngine.friendlyError(e))
        }

        val platform = platformOf(host)
        val maxHeight = info.formats?.maxOfOrNull { it.height } ?: 0

        VideoMetadata(
            title = info.title?.takeIf { it.isNotBlank() } ?: "$platform video",
            url = url,
            platform = platform,
            duration = formatDuration(info.duration.toLong()),
            thumbnailUrl = info.thumbnail.orEmpty(),
            availableQualities = Qualities.optionsFor(maxHeight)
        )
    }

    /** Matches on the real host, so "dropbox.com" is no longer mistaken for "x.com". */
    fun platformOf(rawHost: String): String {
        val h = rawHost.lowercase(Locale.ROOT).removePrefix("www.")
        fun isHost(vararg domains: String) = domains.any { h == it || h.endsWith(".$it") }
        return when {
            isHost("youtube.com", "youtu.be", "youtube-nocookie.com") -> "YouTube"
            isHost("tiktok.com") -> "TikTok"
            isHost("instagram.com", "instagr.am") -> "Instagram"
            isHost("facebook.com", "fb.watch", "fb.com") -> "Facebook"
            isHost("twitter.com", "x.com", "t.co") -> "X / Twitter"
            else -> h
        }
    }

    private fun formatDuration(seconds: Long): String {
        if (seconds <= 0) return "Unknown"
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }
}
