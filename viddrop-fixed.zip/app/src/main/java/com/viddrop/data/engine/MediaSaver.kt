package com.viddrop.data.engine

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.File
import java.io.IOException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Saves finished files straight into the public gallery: Movies/VidDrop (video) or Music/VidDrop (audio). */
object MediaSaver {
    private const val FOLDER = "VidDrop"

    fun save(context: Context, source: File, title: String): Uri {
        val ext = source.extension.lowercase().ifBlank { "mp4" }
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: if (ext == "mp3") "audio/mpeg" else "video/mp4"
        val isAudio = mime.startsWith("audio")
        val name = safeName(title) + "." + ext
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            saveScoped(context, source, name, mime, isAudio)
        } else {
            saveLegacy(context, source, name, mime, isAudio)
        }
    }

    private fun saveScoped(context: Context, source: File, name: String, mime: String, isAudio: Boolean): Uri {
        val resolver = context.contentResolver
        val collection = if (isAudio) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        else MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(
                MediaStore.MediaColumns.RELATIVE_PATH,
                (if (isAudio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES) + "/" + FOLDER
            )
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(collection, values) ?: throw IOException("Could not create gallery entry")
        try {
            resolver.openOutputStream(uri)?.use { out ->
                source.inputStream().use { it.copyTo(out, 256 * 1024) }
            } ?: throw IOException("Could not open gallery file for writing")
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        return uri
    }

    @Suppress("DEPRECATION")
    private fun saveLegacy(context: Context, source: File, name: String, mime: String, isAudio: Boolean): Uri {
        val base = if (isAudio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
        val dir = File(Environment.getExternalStoragePublicDirectory(base), FOLDER)
        if (!dir.exists() && !dir.mkdirs()) throw IOException("Cannot create folder ${dir.path} (storage permission denied?)")
        var dest = File(dir, name)
        var i = 1
        while (dest.exists()) {
            dest = File(dir, name.substringBeforeLast('.') + " ($i)." + name.substringAfterLast('.'))
            i++
        }
        source.copyTo(dest)
        var result: Uri? = null
        val latch = CountDownLatch(1)
        MediaScannerConnection.scanFile(context, arrayOf(dest.absolutePath), arrayOf(mime)) { _, uri ->
            result = uri
            latch.countDown()
        }
        latch.await(5, TimeUnit.SECONDS)
        return result ?: Uri.fromFile(dest)
    }

    /** Deletes the gallery file. Silently ignores files we no longer own (e.g. after reinstall). */
    fun delete(context: Context, uriString: String) {
        if (uriString.isBlank()) return
        runCatching {
            val uri = Uri.parse(uriString)
            if (uri.scheme == "file") File(uri.path!!).delete()
            else context.contentResolver.delete(uri, null, null)
        }
    }

    private fun safeName(title: String): String =
        title.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().take(80).trim('.', ' ').ifBlank { "video" }
}
