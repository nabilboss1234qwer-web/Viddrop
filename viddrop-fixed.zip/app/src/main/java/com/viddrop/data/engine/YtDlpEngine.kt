package com.viddrop.data.engine

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL

/** Wraps yt-dlp (+ffmpeg) that runs on-device. Handles YouTube, TikTok, Instagram, Facebook, X and 1000+ other sites. */
object YtDlpEngine {
    @Volatile private var ready = false
    private val lock = Any()

    /** Safe to call many times / from any background thread. First call unpacks python+ffmpeg (a few seconds). */
    fun ensureInit(context: Context) {
        if (ready) return
        synchronized(lock) {
            if (ready) return
            val app = context.applicationContext
            YoutubeDL.getInstance().init(app)
            FFmpeg.getInstance().init(app)
            ready = true
        }
    }

    /** Sites change often; updating yt-dlp is what keeps downloads working. Returns a short status string. */
    fun update(context: Context): String {
        ensureInit(context)
        val status = YoutubeDL.getInstance().updateYoutubeDL(context.applicationContext, YoutubeDL.UpdateChannel.STABLE)
        return when (status) {
            YoutubeDL.UpdateStatus.DONE -> "Download engine updated"
            YoutubeDL.UpdateStatus.ALREADY_UP_TO_DATE -> "Already up to date"
            else -> "Update finished"
        }
    }

    /** Pulls the useful single line out of yt-dlp's noisy stderr. */
    fun friendlyError(e: Throwable): String {
        val msg = e.message.orEmpty()
        val line = msg.lines().lastOrNull { it.contains("ERROR:") }
            ?.substringAfter("ERROR:")?.trim()
        return (line?.takeIf { it.isNotBlank() }
            ?: msg.lines().firstOrNull { it.isNotBlank() }
            ?: e.javaClass.simpleName).take(220)
    }
}
