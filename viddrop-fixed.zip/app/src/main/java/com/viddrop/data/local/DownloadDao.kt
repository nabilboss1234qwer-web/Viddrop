package com.viddrop.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * All state changes are targeted UPDATE queries with status guards, so a late progress update
 * can never overwrite CANCELLED/COMPLETED (fixes the old read-copy-write race).
 */
@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY downloadDate DESC")
    fun getAllDownloads(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun getDownloadById(id: Long): DownloadEntity?

    @Query("SELECT status FROM downloads WHERE id = :id")
    suspend fun statusOf(id: Long): String?

    @Query("SELECT COUNT(*) FROM downloads WHERE url = :url AND status IN ('QUEUED','DOWNLOADING')")
    suspend fun countActiveByUrl(url: String): Int

    @Insert
    suspend fun insertDownload(download: DownloadEntity): Long

    @Query("UPDATE downloads SET status = 'DOWNLOADING', progress = -1, errorMessage = '' WHERE id = :id AND status = 'QUEUED'")
    suspend fun markDownloading(id: Long): Int

    // Non-suspend on purpose: called from yt-dlp's blocking progress callback (already on an IO thread).
    @Query("UPDATE downloads SET progress = :progress, fileSize = :size WHERE id = :id AND status = 'DOWNLOADING'")
    fun updateProgress(id: Long, progress: Float, size: String): Int

    @Query("UPDATE downloads SET status = 'COMPLETED', progress = 1, localUri = :uri, fileSize = :size, errorMessage = '' WHERE id = :id AND status = 'DOWNLOADING'")
    suspend fun markCompleted(id: Long, uri: String, size: String): Int

    @Query("UPDATE downloads SET status = 'FAILED', progress = 0, errorMessage = :error WHERE id = :id AND status IN ('QUEUED','DOWNLOADING')")
    suspend fun markFailed(id: Long, error: String): Int

    @Query("UPDATE downloads SET status = 'CANCELLED', progress = 0 WHERE id = :id AND status IN ('QUEUED','DOWNLOADING')")
    suspend fun markCancelled(id: Long): Int

    @Query("UPDATE downloads SET status = 'QUEUED', progress = 0, errorMessage = '', downloadDate = :now WHERE id = :id AND status IN ('FAILED','CANCELLED')")
    suspend fun requeue(id: Long, now: Long): Int

    @Query("UPDATE downloads SET status = 'FAILED', progress = 0, errorMessage = 'Interrupted (app was closed)' WHERE status IN ('QUEUED','DOWNLOADING') AND downloadDate < :before")
    suspend fun failInterrupted(before: Long): Int

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteDownload(id: Long)

    @Query("DELETE FROM downloads WHERE status NOT IN ('QUEUED','DOWNLOADING')")
    suspend fun clearFinished(): Int
}
