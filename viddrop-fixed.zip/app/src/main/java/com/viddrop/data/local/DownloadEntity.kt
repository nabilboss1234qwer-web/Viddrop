package com.viddrop.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val url: String,
    val platform: String,
    val quality: String,
    val duration: String,
    val fileSize: String,
    /** content:// Uri of the saved file in the public gallery (Movies/VidDrop or Music/VidDrop). */
    val localUri: String,
    val thumbnailUrl: String,
    val downloadDate: Long,
    /** QUEUED, DOWNLOADING, COMPLETED, FAILED, CANCELLED */
    val status: String,
    val progress: Float,
    @ColumnInfo(defaultValue = "''") val errorMessage: String = ""
)
