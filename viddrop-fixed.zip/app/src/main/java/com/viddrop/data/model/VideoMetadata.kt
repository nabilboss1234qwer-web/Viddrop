package com.viddrop.data.model

data class VideoMetadata(
    val title: String,
    /** Original page URL; yt-dlp resolves the real media streams at download time. */
    val url: String,
    val platform: String,
    val duration: String,
    val thumbnailUrl: String,
    val availableQualities: List<String>
)
