package com.viddrop.data.repository

import android.content.Context
import android.net.ConnectivityManager
import android.os.SystemClock
import com.viddrop.data.engine.MediaSaver
import com.viddrop.data.engine.YtDlpEngine
import com.viddrop.data.local.DownloadDao
import com.viddrop.data.local.DownloadEntity
import com.viddrop.data.model.VideoMetadata
import com.viddrop.data.settings.Qualities
import com.viddrop.data.settings.SettingsStore
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.Locale

class DownloadRepository(
    context: Context,
    private val dao: DownloadDao,
    private val settings: SettingsStore
) {
    private val app = context.applicationContext
    val allDownloads = dao.getAllDownloads()

    private fun processId(id: Long) = "dl_$id"

    private val tmpRoot: File
        get() = File(app.getExternalFilesDir(null) ?: app.filesDir, "tmp").also { it.mkdirs() }

    /** Inserts a QUEUED row and returns immediately. Returns null if the same URL is already downloading. */
    suspend fun enqueue(meta: VideoMetadata, quality: String): Long? = withContext(Dispatchers.IO) {
        if (dao.countActiveByUrl(meta.url) > 0) return@withContext null
        dao.insertDownload(
            DownloadEntity(
                title = meta.title,
                url = meta.url,
                platform = meta.platform,
                quality = quality,
                duration = meta.duration,
                fileSize = "Starting…",
                localUri = "",
                thumbnailUrl = meta.thumbnailUrl,
                downloadDate = System.currentTimeMillis(),
                status = "QUEUED",
                progress = 0f
            )
        )
    }

    /** Runs one download to completion. Called by DownloadService. */
    suspend fun run(id: Long) = withContext(Dispatchers.IO) {
        val item = dao.getDownloadById(id) ?: return@withContext
        if (dao.markDownloading(id) == 0) return@withContext // cancelled/deleted before it started

        if (settings.wifiOnly && isMetered()) {
            dao.markFailed(id, "Wi-Fi only is ON. Connect to Wi-Fi or turn it off in Settings.")
            return@withContext
        }

        val workDir = File(tmpRoot, processId(id)).apply { deleteRecursively(); mkdirs() }
        try {
            YtDlpEngine.ensureInit(app)
            val request = buildRequest(item, workDir)

            var lastWrite = 0L
            var best = 0f
            YoutubeDL.getInstance().execute(request, processId(id)) { progress, _, _ ->
                val now = SystemClock.elapsedRealtime()
                if (progress >= 0f && now - lastWrite >= 700) {
                    lastWrite = now
                    // never go backwards (video and audio streams each report 0-100%)
                    best = maxOf(best, (progress / 100f).coerceIn(0f, 0.99f))
                    dao.updateProgress(id, best, "${(best * 100).toInt()}%")
                }
            }

            if (dao.statusOf(id) != "DOWNLOADING") return@withContext // cancelled while finishing

            val output = workDir.listFiles()
                ?.filter { it.isFile && it.extension !in setOf("part", "ytdl", "temp", "tmp", "json") }
                ?.maxByOrNull { it.length() }
            if (output == null || output.length() == 0L) throw IOException("Download finished but no file was produced")

            val uri = MediaSaver.save(app, output, item.title)
            val size = String.format(Locale.US, "%.1f MB", output.length() / (1024 * 1024.0))
            dao.markCompleted(id, uri.toString(), size)
        } catch (e: CancellationException) {
            withContext(NonCancellable) { dao.markFailed(id, "Interrupted") }
            throw e
        } catch (e: Exception) {
            // If the user cancelled, status is already CANCELLED and this guarded update does nothing.
            dao.markFailed(id, YtDlpEngine.friendlyError(e))
        } finally {
            workDir.deleteRecursively()
        }
    }

    private fun buildRequest(item: DownloadEntity, workDir: File) = YoutubeDLRequest(item.url).apply {
        addOption("--no-playlist")
        addOption("--no-mtime")
        addOption("--retries", "5")
        addOption("--socket-timeout", "30")
        addOption("--concurrent-fragments", "4")
        addOption("-o", "${workDir.absolutePath}/media.%(ext)s")
        if (Qualities.isAudio(item.quality)) {
            addOption("-f", "ba/b")
            addOption("-x")
            addOption("--audio-format", "mp3")
            addOption("--audio-quality", "0")
        } else {
            // Best video + best audio (needs merging for 1080p on most sites), capped at the chosen height,
            // preferring H.264/AAC so the result plays in every gallery/player. TikTok: yt-dlp prefers the
            // un-watermarked stream whenever the site serves one.
            val h = Qualities.height(item.quality)
            addOption("-f", "bv*+ba/b")
            addOption("-S", if (h > 0) "res:$h,vcodec:h264,acodec:m4a" else "res,vcodec:h264,acodec:m4a")
            addOption("--merge-output-format", "mp4")
        }
    }

    private fun isMetered(): Boolean {
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        return cm?.isActiveNetworkMetered ?: false
    }

    suspend fun cancel(id: Long) = withContext(Dispatchers.IO) {
        dao.markCancelled(id)
        YoutubeDL.getInstance().destroyProcessById(processId(id))
        Unit
    }

    /** Returns true if the item was re-queued and the service should be started for it. */
    suspend fun retry(id: Long): Boolean = withContext(Dispatchers.IO) {
        dao.requeue(id, System.currentTimeMillis()) > 0
    }

    /** Removes the entry AND the saved video/audio file. Stops the download first if it's running. */
    suspend fun delete(id: Long) = withContext(Dispatchers.IO) {
        val item = dao.getDownloadById(id)
        if (item != null) {
            if (item.status == "QUEUED" || item.status == "DOWNLOADING") cancel(id)
            MediaSaver.delete(app, item.localUri)
        }
        dao.deleteDownload(id)
    }

    /** Clears finished/failed entries only. Active downloads and the saved files in your gallery are kept. */
    suspend fun clearHistory() = withContext(Dispatchers.IO) { dao.clearFinished(); Unit }

    /** After a crash/kill nothing is really running, so don't leave rows stuck on DOWNLOADING forever. */
    suspend fun recoverInterrupted(processStart: Long) = withContext(Dispatchers.IO) {
        dao.failInterrupted(processStart)
        tmpRoot.listFiles()?.forEach { it.deleteRecursively() }
    }
}
