package com.viddrop.data.settings

import android.content.Context

/** Persistent user settings (survive app restarts). */
class SettingsStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("viddrop_settings", Context.MODE_PRIVATE)

    var autoDetectClipboard: Boolean
        get() = prefs.getBoolean("auto_clipboard", true)
        set(v) = prefs.edit().putBoolean("auto_clipboard", v).apply()

    var wifiOnly: Boolean
        get() = prefs.getBoolean("wifi_only", false)
        set(v) = prefs.edit().putBoolean("wifi_only", v).apply()

    var notifications: Boolean
        get() = prefs.getBoolean("notifications", true)
        set(v) = prefs.edit().putBoolean("notifications", v).apply()

    var defaultQuality: String
        get() = prefs.getString("default_quality", Qualities.FULL_HD) ?: Qualities.FULL_HD
        set(v) = prefs.edit().putString("default_quality", v).apply()

    var lastEngineUpdate: Long
        get() = prefs.getLong("last_engine_update", 0L)
        set(v) = prefs.edit().putLong("last_engine_update", v).apply()
}

object Qualities {
    const val FULL_HD = "1080p Full HD"
    const val MAX = "Max quality (4K+)"
    const val HD = "720p"
    const val SD = "480p"
    const val AUDIO = "Audio MP3"

    val presets = listOf(FULL_HD, MAX, HD, SD, AUDIO)

    fun isAudio(q: String) = q.contains("Audio", ignoreCase = true)

    /** Max video height encoded in the label, e.g. "1080p Full HD" -> 1080, "Best (720p)" -> 720. */
    fun height(q: String): Int =
        if (q == MAX) 0 else Regex("(\\d{3,4})p").find(q)?.groupValues?.get(1)?.toIntOrNull() ?: 1080

    /** Quality options that make sense for a video whose tallest stream is [maxHeight] (0 = unknown). */
    fun optionsFor(maxHeight: Int): List<String> {
        val video = if (maxHeight > 1080) {
            listOf(FULL_HD, MAX, HD, SD)
        } else if (maxHeight <= 0 || maxHeight == 1080) {
            listOf(FULL_HD, HD, SD)
        } else {
            val lower = listOf(HD to 720, SD to 480).filter { it.second < maxHeight }.map { it.first }
            listOf("Best (${maxHeight}p)") + lower
        }
        return video + AUDIO
    }
}
