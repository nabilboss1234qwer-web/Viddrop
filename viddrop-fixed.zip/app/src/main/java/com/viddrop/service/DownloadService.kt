package com.viddrop.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.viddrop.App
import com.viddrop.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/**
 * Foreground service that actually performs downloads, so they keep running when the app is
 * minimised or swiped away.
 */
class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val jobs = ConcurrentHashMap<Long, Job>()
    private lateinit var nm: NotificationManager
    private var lastNotifKey = ""

    private val container get() = (application as App).container

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createChannels()
        // Live progress in the ongoing notification
        scope.launch {
            container.repository.allDownloads.collect { list ->
                val active = list.filter { it.status == "DOWNLOADING" || it.status == "QUEUED" }
                if (active.isEmpty()) return@collect
                val known = active.filter { it.progress >= 0f }
                val pct = if (known.isEmpty()) -1 else (known.map { it.progress }.average() * 100).toInt()
                val text = if (active.size == 1) active[0].title else "${active.size} downloads"
                val key = "$text|$pct"
                if (key != lastNotifKey) {
                    lastNotifKey = key
                    nm.notify(FOREGROUND_ID, buildForeground(text, pct))
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notif = buildForeground("Preparing download…", -1)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(FOREGROUND_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(FOREGROUND_ID, notif)
        }

        val id = intent?.getLongExtra(EXTRA_ID, -1L) ?: -1L
        if (id > 0 && !jobs.containsKey(id)) {
            jobs[id] = scope.launch {
                try {
                    container.repository.run(id)
                    notifyResult(id)
                } finally {
                    // Back on the main thread so it can't race with a new onStartCommand.
                    withContext(NonCancellable + Dispatchers.Main) {
                        jobs.remove(id)
                        if (jobs.isEmpty()) {
                            stopForeground(STOP_FOREGROUND_REMOVE)
                            stopSelf()
                        }
                    }
                }
            }
        } else if (jobs.isEmpty()) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private suspend fun notifyResult(id: Long) {
        if (!container.settings.notifications) return
        val item = container.database.downloadDao().getDownloadById(id) ?: return
        val (title, text) = when (item.status) {
            "COMPLETED" -> "Download complete" to item.title
            "FAILED" -> "Download failed" to "${item.title}: ${item.errorMessage}"
            else -> return
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CHANNEL_RESULT)
            .setSmallIcon(if (item.status == "COMPLETED") android.R.drawable.stat_sys_download_done else android.R.drawable.stat_notify_error)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(RESULT_BASE_ID + id.toInt(), n)
    }

    private fun buildForeground(text: String, pct: Int): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("VidDrop is downloading")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .setProgress(100, pct.coerceAtLeast(0), pct < 0)
            .build()
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_PROGRESS, "Download progress", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_RESULT, "Download results", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    companion object {
        private const val EXTRA_ID = "download_id"
        private const val FOREGROUND_ID = 1
        private const val RESULT_BASE_ID = 1000
        private const val CHANNEL_PROGRESS = "viddrop_progress"
        private const val CHANNEL_RESULT = "viddrop_result"

        fun start(context: Context, downloadId: Long) {
            val i = Intent(context, DownloadService::class.java).putExtra(EXTRA_ID, downloadId)
            androidx.core.content.ContextCompat.startForegroundService(context, i)
        }
    }
}
