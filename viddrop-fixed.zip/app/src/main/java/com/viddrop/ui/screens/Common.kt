package com.viddrop.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.Dp
import com.viddrop.data.local.DownloadEntity
import com.viddrop.data.settings.Qualities
import com.viddrop.ui.theme.GlassBorder
import com.viddrop.ui.theme.NeonCyan

fun isActive(status: String) = status == "QUEUED" || status == "DOWNLOADING"

fun subtitleOf(item: DownloadEntity): String = when (item.status) {
    "FAILED" -> item.errorMessage.ifBlank { "Download failed" }
    "QUEUED" -> "${item.platform} • Starting…"
    else -> "${item.platform} • ${item.quality} • ${item.fileSize}"
}

/** Determinate when progress is known, indeterminate otherwise (progress < 0 or QUEUED). */
@Composable
fun DownloadProgressBar(item: DownloadEntity, height: Dp) {
    val m = Modifier.fillMaxWidth().height(height).clip(CircleShape)
    if (item.status == "DOWNLOADING" && item.progress >= 0f) {
        LinearProgressIndicator(
            progress = { item.progress.coerceIn(0f, 1f) },
            modifier = m, color = NeonCyan, trackColor = GlassBorder
        )
    } else {
        LinearProgressIndicator(modifier = m, color = NeonCyan, trackColor = GlassBorder)
    }
}

fun openMedia(context: Context, uriString: String) {
    if (uriString.isBlank()) return
    val uri = Uri.parse(uriString)
    val mime = if (uriString.contains("/audio/")) "audio/*" else "video/*"
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, mime)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Can't open this file (it may have been moved or deleted)", Toast.LENGTH_SHORT).show()
    }
}

fun shareMedia(context: Context, item: DownloadEntity) {
    val send = Intent(Intent.ACTION_SEND).apply {
        if (item.localUri.isNotBlank()) {
            putExtra(Intent.EXTRA_STREAM, Uri.parse(item.localUri))
            type = if (Qualities.isAudio(item.quality)) "audio/*" else "video/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } else {
            putExtra(Intent.EXTRA_TEXT, item.url)
            type = "text/plain"
        }
    }
    try {
        context.startActivity(Intent.createChooser(send, "Share"))
    } catch (e: Exception) {
        Toast.makeText(context, "Nothing to share with", Toast.LENGTH_SHORT).show()
    }
}
