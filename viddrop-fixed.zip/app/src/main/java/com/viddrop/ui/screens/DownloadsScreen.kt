package com.viddrop.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.viddrop.data.local.DownloadEntity
import com.viddrop.ui.theme.*
import com.viddrop.ui.viewmodel.VidDropViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DownloadsScreen(viewModel: VidDropViewModel) {
    val context = LocalContext.current
    val downloads by viewModel.downloads.collectAsState(initial = emptyList())

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(DarkBackground, DarkSurface, DarkBackground)
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Downloads",
                        color = TextPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Manage your saved media library",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }

                if (downloads.isNotEmpty()) {
                    TextButton(onClick = { viewModel.clearHistory() }) {
                        Text("Clear History", color = ErrorRed)
                    }
                }
            }

            if (downloads.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudDownload,
                            contentDescription = null,
                            tint = TextSecondary.copy(alpha = 0.4f),
                            modifier = Modifier.size(64.dp)
                        )
                        Text(
                            text = "No saved videos yet",
                            color = TextSecondary,
                            fontSize = 16.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentPadding = PaddingValues(bottom = 100.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(downloads, key = { it.id }) { item ->
                        DownloadCardFull(item = item, viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun DownloadCardFull(item: DownloadEntity, viewModel: VidDropViewModel) {
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()) }
    val dateStr = dateFormat.format(Date(item.downloadDate))
    var confirmDelete by remember { mutableStateOf(false) }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete video?") },
            text = { Text("This removes it from the list and deletes the saved file from your device.") },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; viewModel.deleteDownload(item.id) }) {
                    Text("Delete", color = ErrorRed)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Keep") } }
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, GlassBorder, RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = GlassSurface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(DarkBackground)
                ) {
                    AsyncImage(
                        model = item.thumbnailUrl.ifBlank { null },
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = item.title,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = subtitleOf(item),
                        color = if (item.status == "FAILED") ErrorRed else TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = dateStr,
                        color = TextSecondary.copy(alpha = 0.7f),
                        fontSize = 11.sp
                    )
                }
            }

            if (isActive(item.status)) {
                DownloadProgressBar(item, 6.dp)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val chipColor = when (item.status) {
                    "COMPLETED" -> SuccessGreen
                    "FAILED" -> ErrorRed
                    else -> NeonCyan
                }
                Surface(shape = RoundedCornerShape(6.dp), color = chipColor.copy(alpha = 0.2f)) {
                    Text(
                        text = item.status,
                        color = chipColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    when (item.status) {
                        "COMPLETED" -> {
                            IconButton(onClick = { openMedia(context, item.localUri) }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = NeonCyan)
                            }
                            IconButton(onClick = { shareMedia(context, item) }) {
                                Icon(Icons.Default.Share, contentDescription = "Share", tint = TextPrimary)
                            }
                        }
                        "QUEUED", "DOWNLOADING" -> IconButton(onClick = { viewModel.cancelDownload(item.id) }) {
                            Icon(Icons.Default.Cancel, contentDescription = "Cancel", tint = ErrorRed)
                        }
                        else -> IconButton(onClick = { viewModel.retryDownload(item.id) }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Retry", tint = NeonCyan)
                        }
                    }

                    IconButton(onClick = {
                        if (item.status == "COMPLETED") confirmDelete = true else viewModel.deleteDownload(item.id)
                    }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TextSecondary)
                    }
                }
            }
        }
    }
}
