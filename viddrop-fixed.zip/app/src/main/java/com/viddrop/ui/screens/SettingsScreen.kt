package com.viddrop.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.viddrop.ui.theme.*
import com.viddrop.ui.viewmodel.VidDropViewModel

@Composable
fun SettingsScreen(viewModel: VidDropViewModel) {
    val context = LocalContext.current
    var showAboutDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(DarkBackground, DarkSurface, DarkBackground)
                )
            )
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column {
                    Text(
                        text = "Settings",
                        color = TextPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Preferences and application info",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }

            item {
                SettingsSectionTitle("Download Preferences")
            }

            item {
                SettingsToggleCard(
                    title = "Auto-detect Clipboard URL",
                    subtitle = "Automatically detect supported video links when opening",
                    icon = Icons.Default.ContentPaste,
                    checked = viewModel.autoDetectClipboard,
                    onCheckedChange = { viewModel.setAutoDetectClipboard(it) }
                )
            }

            item {
                SettingsToggleCard(
                    title = "Wi-Fi Only Downloads",
                    subtitle = "Prevent downloading over cellular data",
                    icon = Icons.Default.Wifi,
                    checked = viewModel.wifiOnlyDownloads,
                    onCheckedChange = { viewModel.setWifiOnly(it) }
                )
            }

            item {
                SettingsToggleCard(
                    title = "Download Notifications",
                    subtitle = "Show notification progress during downloads",
                    icon = Icons.Default.Notifications,
                    checked = viewModel.downloadNotifications,
                    onCheckedChange = { viewModel.setDownloadNotifications(it) }
                )
            }

            item {
                SettingsSectionTitle("Storage & Data")
            }

            item {
                SettingsActionCard(
                    title = "Default Quality",
                    subtitle = viewModel.defaultQuality,
                    icon = Icons.Default.HighQuality,
                    onClick = {
                        val presets = com.viddrop.data.settings.Qualities.presets
                        val next = presets[(presets.indexOf(viewModel.defaultQuality) + 1) % presets.size]
                        viewModel.setDefaultQuality(next)
                        Toast.makeText(context, "Default quality set to ${viewModel.defaultQuality}", Toast.LENGTH_SHORT).show()
                    }
                )
            }

            item {
                SettingsActionCard(
                    title = "Clear Download History",
                    subtitle = "Remove finished/failed entries (saved videos stay in your gallery)",
                    icon = Icons.Default.DeleteSweep,
                    onClick = {
                        viewModel.clearHistory()
                        Toast.makeText(context, "Download history cleared", Toast.LENGTH_SHORT).show()
                    }
                )
            }

            item {
                SettingsActionCard(
                    title = "Update Download Engine",
                    subtitle = viewModel.engineStatus ?: "Keeps YouTube, TikTok, Instagram etc. working (auto-checks daily)",
                    icon = Icons.Default.SystemUpdate,
                    onClick = { viewModel.updateEngine() }
                )
            }

            item {
                SettingsSectionTitle("Developer & About")
            }

            item {
                SettingsActionCard(
                    title = "Developer",
                    subtitle = "Nabil Rahman (owner@nabilxchat.xyz)",
                    icon = Icons.Default.Person,
                    onClick = {
                        val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                            data = android.net.Uri.parse("mailto:owner@nabilxchat.xyz")
                            putExtra(Intent.EXTRA_SUBJECT, "VidDrop Support / Inquiry")
                        }
                        try {
                            context.startActivity(emailIntent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Email: owner@nabilxchat.xyz", Toast.LENGTH_LONG).show()
                        }
                    }
                )
            }

            item {
                SettingsActionCard(
                    title = "Privacy Information",
                    subtitle = "Read our strict zero-logging privacy policy",
                    icon = Icons.Default.PrivacyTip,
                    onClick = { showPrivacyDialog = true }
                )
            }

            item {
                SettingsActionCard(
                    title = "About VidDrop",
                    subtitle = "Version 1.0.0 • Developed by Nabil Rahman",
                    icon = Icons.Default.Info,
                    onClick = { showAboutDialog = true }
                )
            }
        }
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            containerColor = DarkSurface,
            title = { Text("About VidDrop", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "VidDrop is a modern social-video downloader designed for high-performance public video downloading with clean dark glassmorphism UI.",
                        color = TextSecondary
                    )
                    Text(
                        "Developer: Nabil Rahman\nEmail: owner@nabilxchat.xyz",
                        color = NeonCyan,
                        fontWeight = FontWeight.Medium
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) {
                    Text("Close", color = NeonCyan)
                }
            }
        )
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            containerColor = DarkSurface,
            title = { Text("Privacy Policy", color = TextPrimary) },
            text = {
                Text(
                    "VidDrop respects your privacy. We do not collect unnecessary personal information, store URLs on remote servers, or track your browsing activity. All downloads are saved directly to your device storage.\n\nDeveloper: Nabil Rahman (owner@nabilxchat.xyz)",
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text("OK", color = NeonCyan)
                }
            }
        )
    }
}

@Composable
fun SettingsSectionTitle(title: String) {
    Text(
        text = title,
        color = NeonCyan,
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
    )
}

@Composable
fun SettingsToggleCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, GlassBorder, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = GlassSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = NeonCyan)
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(text = title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Text(text = subtitle, color = TextSecondary, fontSize = 12.sp)
                }
            }

            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = DarkBackground,
                    checkedTrackColor = NeonCyan,
                    uncheckedThumbColor = TextSecondary,
                    uncheckedTrackColor = DarkBackground
                )
            )
        }
    }
}

@Composable
fun SettingsActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = GlassSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = NeonCyan)
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(text = title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Text(text = subtitle, color = TextSecondary, fontSize = 12.sp)
                }
            }

            Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = TextSecondary)
        }
    }
}
