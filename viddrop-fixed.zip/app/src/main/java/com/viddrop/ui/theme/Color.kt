package com.viddrop.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0A0A0F)
val DarkSurface = Color(0xFF14141E)
val GlassSurface = Color(0x1FFFFFFF)
val GlassBorder = Color(0x33FFFFFF)

val NeonCyan = Color(0xFF00F0FF)
val NeonViolet = Color(0xFF8A2BE2)
val NeonPink = Color(0xFFFF007F)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFA0A0AB)
val SuccessGreen = Color(0xFF00E676)
val ErrorRed = Color(0xFFFF5252)
