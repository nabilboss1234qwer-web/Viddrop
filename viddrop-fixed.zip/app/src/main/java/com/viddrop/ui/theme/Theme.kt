package com.viddrop.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val VidDropDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    secondary = NeonViolet,
    background = DarkBackground,
    surface = DarkSurface,
    onPrimary = DarkBackground,
    onSecondary = TextPrimary,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun VidDropTheme(
    darkTheme: Boolean = true, // Dark-first interface as requested
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = VidDropDarkColorScheme,
        typography = Typography,
        content = content
    )
}
