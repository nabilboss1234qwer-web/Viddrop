package com.viddrop.ui.viewmodel

import android.app.Application
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.viddrop.App
import com.viddrop.data.engine.MediaResolver
import com.viddrop.data.engine.YtDlpEngine
import com.viddrop.data.local.DownloadEntity
import com.viddrop.data.model.VideoMetadata
import com.viddrop.service.DownloadService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class VidDropViewModel(application: Application) : AndroidViewModel(application) {

    private val container = (application as App).container
    private val repository = container.repository
    private val settings = container.settings

    val downloads: StateFlow<List<DownloadEntity>> = repository.allDownloads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    var urlInput by mutableStateOf("")
        private set
    var detectedMetadata by mutableStateOf<VideoMetadata?>(null)
        private set
    var selectedQuality by mutableStateOf(settings.defaultQuality)
        private set
    var errorMessage by mutableStateOf<String?>(null)
        private set
    var isPreviewVisible by mutableStateOf(false)
        private set
    var isLoading by mutableStateOf(false)
        private set
    var engineStatus by mutableStateOf<String?>(null)
        private set

    // Settings (persisted)
    var autoDetectClipboard by mutableStateOf(settings.autoDetectClipboard)
        private set
    var wifiOnlyDownloads by mutableStateOf(settings.wifiOnly)
        private set
    var downloadNotifications by mutableStateOf(settings.notifications)
        private set
    var defaultQuality by mutableStateOf(settings.defaultQuality)
        private set

    fun setAutoDetectClipboard(v: Boolean) { autoDetectClipboard = v; settings.autoDetectClipboard = v }
    fun setWifiOnly(v: Boolean) { wifiOnlyDownloads = v; settings.wifiOnly = v }
    fun setDownloadNotifications(v: Boolean) { downloadNotifications = v; settings.notifications = v }
    fun setDefaultQuality(v: String) { defaultQuality = v; settings.defaultQuality = v }

    private var detectRequestId = 0
    private var lastClipboard = ""

    fun updateUrlInput(newUrl: String) {
        urlInput = newUrl
        errorMessage = null
    }

    fun detectAndPreviewUrl(input: String = urlInput) {
        if (input.isBlank()) {
            errorMessage = "Please enter a valid video URL."
            return
        }
        val myId = ++detectRequestId // a newer request supersedes older ones
        isLoading = true
        errorMessage = null

        viewModelScope.launch {
            try {
                val metadata = MediaResolver.resolve(getApplication(), input)
                if (myId != detectRequestId) return@launch
                detectedMetadata = metadata
                selectedQuality = metadata.availableQualities.firstOrNull { it == defaultQuality }
                    ?: metadata.availableQualities.first()
                isPreviewVisible = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (myId != detectRequestId) return@launch
                errorMessage = e.localizedMessage ?: "Failed to resolve video URL. Please check connection."
                detectedMetadata = null
                isPreviewVisible = false
            } finally {
                if (myId == detectRequestId) isLoading = false
            }
        }
    }

    fun pasteFromClipboard(context: Context) {
        val text = clipboardText(context)
        if (text.isNullOrBlank()) {
            errorMessage = "No text found in clipboard."
            return
        }
        lastClipboard = text
        urlInput = text
        detectAndPreviewUrl(text)
    }

    /** Called when the app comes to the foreground (Android only allows clipboard reads then). */
    fun autoDetectFromClipboard(context: Context) {
        if (!autoDetectClipboard || isLoading) return
        val text = clipboardText(context)?.trim() ?: return
        val looksLikeUrl = (text.startsWith("http://") || text.startsWith("https://")) && !text.contains(' ')
        if (!looksLikeUrl || text == lastClipboard) return
        lastClipboard = text
        urlInput = text
        detectAndPreviewUrl(text)
    }

    private fun clipboardText(context: Context): String? {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return null
        val clip = cm.primaryClip ?: return null
        if (clip.itemCount == 0) return null
        return clip.getItemAt(0).text?.toString()
    }

    fun selectQuality(quality: String) {
        selectedQuality = quality
    }

    fun startDownload() {
        val meta = detectedMetadata ?: return
        val quality = selectedQuality
        viewModelScope.launch {
            val id = repository.enqueue(meta, quality)
            if (id == null) {
                errorMessage = "This video is already downloading."
                return@launch
            }
            DownloadService.start(getApplication(), id)
            // UI is released immediately; the download continues in the service.
            isPreviewVisible = false
            urlInput = ""
            detectedMetadata = null
        }
    }

    fun retryDownload(id: Long) {
        viewModelScope.launch {
            if (repository.retry(id)) DownloadService.start(getApplication(), id)
        }
    }

    fun cancelDownload(id: Long) {
        viewModelScope.launch { repository.cancel(id) }
    }

    fun deleteDownload(id: Long) {
        viewModelScope.launch { repository.delete(id) }
    }

    fun clearHistory() {
        viewModelScope.launch { repository.clearHistory() }
    }

    fun updateEngine() {
        engineStatus = "Updating…"
        viewModelScope.launch {
            engineStatus = try {
                withContext(Dispatchers.IO) { YtDlpEngine.update(getApplication()) }
            } catch (e: Exception) {
                "Update failed: ${YtDlpEngine.friendlyError(e)}"
            }
        }
    }

    fun dismissPreview() {
        isPreviewVisible = false
    }

    fun dismissError() {
        errorMessage = null
    }
}
